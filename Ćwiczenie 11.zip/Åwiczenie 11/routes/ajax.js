const { Router } = require('express');
var express = require('express');
var router = express.Router();

router.post('/add ', function(req, res, next){
    console.log(req.body);
    let param1 =  number.parseInt(req.body.param1);
    let param2 =  number.parseInt(req.body.param2);
    let wynik = param1+param2;
    let wysylanie = {wynik:wynik};
    console.log(wysylanie);
 
});

module.exports = router;