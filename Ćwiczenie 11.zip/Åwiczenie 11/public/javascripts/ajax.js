const { response } = require("express");

function obsluzOdopowiedz(event){
    console.log(this.readyState);

let wynikDiv = document.getElementById("wynik");
let nowyAkapit = document.createElement("p");
let tekst = document.createTextNode(data.wynik);
nowyAkapit.appendChild(tekst);
wynikDiv.appendChild(nowyAkapit);
        }
 
    function obsluzklik(){
        let param1 = document.forms[0].param1.value;
        let param2 = document.forms[0].param2.value;
        let body = {param1:param1,param2:param2};
    console.log(body);
       fetch('http://localhost:3000/ajax/add',
       {
           method: 'POST',
           headers:{
               'Content-Type' : 'application/json'
           },
           body.JSON.stringify(body);
           }
       ).then(response=>response.json()).then(json=>obsluzOdopowiedz(json)));
    
    }
    
    window.onload = function() {
        document.getElementById("przycisk").onclick=obsluzklik;
    
    }