var max = 0;
var tablica = [1,2,3,4,5,6,7,8,9,10];

for (var i=0; i < tablica.length; i++) {
    if (max <= tablica[i]) {
        max = tablica[i];
    }
}
console.log("Najwieksza liczba z tablicy to:", max);
