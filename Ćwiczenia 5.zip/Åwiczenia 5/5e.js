

var = 10;
function napis(x);
if (x % 2 == 0){
  return ("Jest parzysta");
}
