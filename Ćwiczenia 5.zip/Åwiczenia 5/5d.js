var cyfra1 = 100;
var cyfra2 = 50;
var cyfra3 = 150;
function jaka(x) {
  if (x < Math.max(cyfra2, cyfra3) && x > Matk.min(cyfra2, cyfra3))
  return ("Cyfra pierwsza jest między cyfra drugą a cyfra trzecią");
  else
  return ("Cyfra pierwsza nie jest między cyfra drugą a cyfra trzecią");
}
document.write(jaka(liczba1));
