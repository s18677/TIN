const tab = [1, 2, 3, 4, 5, 6];
function wartosc(x) {
  const tablice = (Math.max.apply(Math, x) -1);
  return tablice;

}
document.write(wartosc(tab));
