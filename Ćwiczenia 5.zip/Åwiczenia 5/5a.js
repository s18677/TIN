
function silnia(n)
{
        wynik = 1;
        while (n > 0)
        {
                wynik = wynik * n ;
                n -- ;
        }
        document.write(wynik);
}

silnia(6);
