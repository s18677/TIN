var licznik = 0;
				  do {
					  prompt ("Podaj liczbe:");
					  licznik++;
				  }
				  while (licznik < 10);
				  prompt("Koniec pętli");
