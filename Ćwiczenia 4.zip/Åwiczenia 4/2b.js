


var x;
  alert ("Podaj numer pietra");

  if(x % 3 == 1) {
    prompt("piatro jest na górze");
  }
  else if(x % 3 == 2) {
    prompt("pietro jest na srodku");
  }
  else {
    prompt("pietro jest na dole");
  }
