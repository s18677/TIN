const tab = ["Polsko", "Japonska", "Akademia", "Technika", "Komputerowych"];
function tablica(tab) {
  return(tab);
}
alert (tablica(tab).join(""));
