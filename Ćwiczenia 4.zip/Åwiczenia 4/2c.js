function readTable (tab) {
  for (var i = 0; i < tab.length; i++) {
    console.log(tab[i]);
  }
};
var kosmetyki = [
  "Tusz", //indeks 0
  "Podklad", //indeks 1
  "Puder", //indeks 2
  "Cien", //indeks 3
  "Korektor", //indeks 4
];
readTable(kosmetyki);
