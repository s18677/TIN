function tab(x, y, z){
var x = document.getElementById("akapit1").value;
document.getElementById("tabela1").innerHTML = x;

var y = document.getElementById("akapit2").value;
document.getElementById("tabela2").innerHTML = y;

var z = document.getElementById("akapit3").value;
document.getElementById("tabela3").innerHTML = z;

document.getElementById("akapit1").value = "";
document.getElementById("akapit2").value = "";
document.getElementById("akapit3").value = "";
};
