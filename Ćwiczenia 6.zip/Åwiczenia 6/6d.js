function student (imie, nazwisko, nr_indeksu, oceny = []){
  this.imie = imie;
  this.nazwisko = nazwisko;
  this.nr_indeksu = nr_indeksu;
  this.oceny = oceny;
}

let uczen = new student ("Katarzna ", "Mnich ", 18677 + " " + [5, 5, 5, 5, 4, 3, 5, 5]);
document.write(uczen.imie + uczen.nazwisko + uczen.nr_indeksu + uczen.oceny);
