var student1 = {
  imie:"Kasia",
  nazwisko: "Mnich",
  numer_indeksu: "s18677"
};
console.console.log(student1.imie + " " + student1.nazwisko + " " + student1.numer_indeksu +" ");
