var student1 = {
  imie:"Kasia",
  nazwisko: "Mnich",
  numer_indeksu: "s18675"
};
let oceny =[4, 5, 5, 5, 3, 4, 4,];
let avg;
srednia_ocen = srednia_ocen(oceny);
function srednia_ocen(n) {
  if (n.length == 0) return 0;
  let razem = 0;
  for (let i = 0; i <n.length; i++ ) {
    razem += n[i]; }
    let avg = razem/n.length;
    return(Math.round(avg * 100) / 100).toFixed(2);
}
console.console.log(student1.imie + " " + student1.nazwisko + " " + student1.numer_indeksu + " " + srednia_ocen(oceny));
