var myObject = new Object();
        myObject.myString = "Kasia";
        myObject.myString = "Mnich";
        myObject.myString = "s18677";
        myObject.myFunc = function(){
                return this.myString;
            };
        myObject.myFunc();
