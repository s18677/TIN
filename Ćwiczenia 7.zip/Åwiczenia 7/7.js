var evt;
function onlyNumberKey(evt) {
	var ASCIICode = (evt.which) ? evt.which : event.keyCode
	if (ASCIICode > 31 && (ASCIICode <48 || ASCIICode >57))
		return false;
	return true;
}
function walidacja() {
	var haslo = "admin";
	var usupelnione = false;
	var uzu1 = 0;
	var formularz = document.forms[0];
	var dane = [];
	
	if (formularz.pass.value == haslo) {
		uzupelnione = true;
		uzu1 = uzu1 + 1;
	} else if (formularz.pass.value != haslo){
		uzupelnione = false;
		alert("Wprowadz dane - haslo: admin");
	}
	if (formularz.telefon.value == !dane || dane<0 || dane >9){
		uzupelnione = false;
		alert("Brakuje odpowiednich danych! Wpisz wyłacznie numery.");
	}
	else {
		uzupelnione = true;
		uzu1 = uzu1 +1;
		
	}
	if (uzu1 == 2)
		formularz.submit();
	
	//B
	
	function tab(x, y, z){
var x = document.getElementById("akapit1").value;
document.getElementById("tabela1").innerHTML = x;

var y = document.getElementById("akapit2").value;
document.getElementById("tabela2").innerHTML = y;

var z = document.getElementById("akapit3").value;
document.getElementById("tabela3").innerHTML = z;

document.getElementById("akapit1").value = "";
document.getElementById("akapit2").value = "";
document.getElementById("akapi31").value = "";
}
};